import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ApiService } from '../shared/api.service';
import { LoanDetailsData } from '../shared/loanDetails.model';

@Component({
  selector: 'app-loan-dashboard',
  templateUrl: './loan-dashboard.component.html',
  styleUrls: ['./loan-dashboard.component.css']
})
export class LoanDashboardComponent implements OnInit {

  formValue!: FormGroup
  getLoanDetailsData: any
  showAdd!: boolean
  showBtn!: boolean

  loanDetailsData: LoanDetailsData = new LoanDetailsData;


  constructor(private formBuilder: FormBuilder, private api: ApiService) { }

  ngOnInit(): void {
    this.formValue = this.formBuilder.group({
      loanName: [''],
      loannumber: [''],
      loanType: [''],
      loanDescription: [''],
      amount: ['']
    })
    this.getLoanDetails() // it is for show details on screen
  }
  clickAddLoanButton() {
    this.formValue.reset();
    this.showAdd = true;
    this.showBtn = false;
  }

  // Now suscribing our data which are mapped via services
  addLoanDetails() {
    this.loanDetailsData.loanName = this.formValue.value.loanName;
    this.loanDetailsData.loanNumber = this.formValue.value.loannumber;
    this.loanDetailsData.loanType = this.formValue.value.loanType;
    this.loanDetailsData.loanDescription = this.formValue.value.loanDescription;
    this.loanDetailsData.amount = this.formValue.value.amount
    console.log(this.loanDetailsData);

    this.api.postLoanDetails(this.loanDetailsData).subscribe(res => {
      console.log(res);
      alert("LoanDetails Added Successfully !!");
      //clear fill from data form
      let ref = document.getElementById('clear');
      ref?.click();

      this.formValue.reset()
      this.getLoanDetails() //when u post any data
    },
      err => {
        alert("Details Not Submitted !")
      }
    )

  }

  //Get Loan Details
  getLoanDetails() {
    this.api.getLoanDetails().subscribe(res => {
      this.getLoanDetailsData = res;
    })

  }

  //Delete Loan Details
  deleteLoanDetails(data: any) {
    this.api.deleteLoanDetails(data.id).subscribe(res => {
      alert("LoanData Deleted Successfully !")
      this.getLoanDetails();
    })
  }
  //Edit Loan Details
  editLoanDetails(data: any) {
    this.showAdd = false;
    this.showBtn = true;
    this.loanDetailsData.id = data.id
    this.formValue.controls['loanName'].setValue(data.loanName);
    this.formValue.controls['loanType'].setValue(data.loanType);
    this.formValue.controls['loanDescription'].setValue(data.loanDescription);
    this.formValue.controls['amount'].setValue(data.amount);
  }
  updateLoanDetails() {
    this.loanDetailsData.loanName = this.formValue.value.loanName;
    this.loanDetailsData.loanType = this.formValue.value.loanType;
    this.loanDetailsData.loanDescription = this.formValue.value.loanDescription;
    this.loanDetailsData.amount = this.formValue.value.amount
    console.log(this.loanDetailsData);

    this.api.updateLoanDetails(this.loanDetailsData, this.loanDetailsData.id).subscribe(res => {
      alert("LoanData Updated Successfully !");
      let ref = document.getElementById('clear');
      ref?.click();

      this.formValue.reset();
      this.getLoanDetails();

    })
  }
}
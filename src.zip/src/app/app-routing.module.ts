import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoanDashboardComponent } from './loan-dashboard/loan-dashboard.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';

const routes: Routes = [{
  path: '', redirectTo: 'login', pathMatch: 'full'
},
{
  path: 'login', component: LoginComponent
},
{
  path: 'signup', component: SignupComponent
},
{
  path: 'loandashboard', component: LoanDashboardComponent
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup
  data:any

  constructor(private formBuilder: FormBuilder, private http: HttpClient, private router: Router) { }

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      email: [''],
      password: ['']

    })
  }
  //login method define
  logIn() {
    this.http.get<any>("http://localhost:3000/signup").subscribe(res => {
      // this.data=res
      // console.log(this.data.emailaddress)
      // if(this.data.email===this.loginForm.value.email)
      // console.log("success")
      const user = res.find((a:any) => {
        console.log(res.emailaddress)
        return a.emailaddress === this.loginForm.value.email && a.password === this.loginForm.value.password
      })
      console.log(this.loginForm.value.email)
      if(user){
        alert("Login is Successful !");
        this.loginForm.reset();
        this.router.navigate(['loandashboard'])
      }
      else{
        alert("User not found !")
      }
      },
      err=>{
        alert("server side error !")

    })
  }


}

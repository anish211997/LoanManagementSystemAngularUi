export class LoanDetailsData {
    id: number = 0;
    loanName: string = '';
    loanNumber:string='';
    loanType: string = '';
    loanDescription: string = '';
    amount: string = '';

}